clc
close all
clear all

n = 300;
A = diag( 6 * ones( n, 1 ) ) + diag( 1 * ones( n - 2, 1 ), -2 ) + diag( 1 * ones( n - 2, 1 ), 2 ) ...
    + diag( -2 * ones( n - 1, 1 ), -1 ) + diag( -2 * ones( n - 1, 1 ), 1 );

%% punto 1 
D = diag( diag( A ) );
BJ = eye( n ) - D \ A;
rhoBJ = max( abs( eig( BJ ) ) ) 

BGS = eye( n ) - tril( A ) \ A;
rhoGS = max( abs( eig( BGS ) ) )

%% punto 3
x = ones( n, 1 );
b = A * x;
toll = 1e-6;
nmax = 1000;
x0 = b;
[ xk, k ] = gs( A, b, x0, toll, nmax );
k
res_norm = norm( b - A * xk ) / norm( b )
err_rel = norm( x - xk ) / norm( x )
err_stim = cond(A) * res_norm

%% punto 4
d = ( cond(A) - 1 ) / ( cond( A ) + 1 );
err_g_k = d^20 * sqrt( ( x - x0 )' * A * ( x - x0 ) )

%% punto 5
betav = 2 : 1: 5;
dv = [];
for beta = betav
    P = diag( beta * ones( n, 1 ) ) + diag( - 1 * ones( n - 1, 1 ), 1 ) + diag( - 1 * ones( n - 1, 1 ), -1 );
    cPA = max(eig(P\A))/min(eig(P\A));
    dPA = ( cPA - 1 ) / ( cPA + 1 );
    dv = [ dv, dPA ];
end
plot( betav, dv, '-ob', 'Linewidth', 3, 'Markersize', 15, 'MarkerFaceColor','b')
hold on 
grid on
xlabel('\beta')
ylabel('d')

%% punto 6
xpcg = pcg(A,b,1e-6,1000,[],[],b);
err = sqrt( (xpcg-x)'*A*(xpcg-x))