clc;
clear all;
close all; 

% definisco l'anno iniziale
year = 0;

% definisco il valore iniziale del deposito
deposit = 10000;

% definisco il vettore che conterra tutti i valori del deposito, anno dopo anno
deposit_values = deposit;

% definisco il tasso di interesse
interest_rate = 1.02;

while (deposit < 1e6)
    year = year + 1;
    deposit = deposit * interest_rate + 10000;
    deposit_values = [deposit_values deposit];
end

% stampo il risultato
year
