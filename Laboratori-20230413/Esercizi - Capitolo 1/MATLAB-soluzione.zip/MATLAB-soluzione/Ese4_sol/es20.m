function es20(n)
r=sqrt(n)-floor(sqrt(n));
if r==0
    disp('E'' un quadrato perfetto');
else
	disp('Non e'' un quadrato perfetto');
end
end
