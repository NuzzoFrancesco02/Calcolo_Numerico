clc
clear

k = 0; % per esempio
s_pari=0;
s_dispari=0;
for i=5*k+k:1000
    if mod(i,2)==0
        s_pari = s_pari+i;
    else
        s_dispari = s_dispari+i;
    end
end
s_pari
s_dispari