clc;
clear all;
close all;

% definisco il raggio del cerchio
r = 1;

% definisco il numero di punti random da utilizzare nelle varie iterazioni
n_points_vector = [100 1000 10000 100000 1000000];

% definisco il vettore che conterra' le approssimazioni di pi greco
approximated_pi = [];

for n_points = n_points_vector
    % definisco una variabile per contare i punti che cadono nel primo quarto del cerchio di centro (0,0) e raggio 1
    points_counter = 0;

    for i = 1:n_points
        % coordinata x: numero random in [0, 1]
        x = rand;

        % coordinata y: numero random in [0, 1]
        y = rand;

        % controllo che il punto estratto sia all'interno del cerchio
        if ( (x^2 + y^2) <= r )
            points_counter = points_counter + 1;
        end
    end

    % calcolo approssimazione di pi greco
    approximated_pi = [approximated_pi 4*points_counter/n_points];
end
approximated_pi

% NB: i risultati cambiano ogni volta che si lancia lo script, poiche' i punti usati sono casuali e dunque il numero
% di punti che cade all'interno del cerchio non e' fisso

