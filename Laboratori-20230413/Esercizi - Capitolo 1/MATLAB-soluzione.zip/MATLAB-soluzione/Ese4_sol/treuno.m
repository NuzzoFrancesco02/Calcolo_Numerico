clc;
clear all;
close all;

%% sottosezione 1

% valori iniziali di n
n0         = [2 4 8 16];
% inizializzazione vettore delle iterazioni
iterazioni = [];

for n = n0 
    % inizializzazione della successione (vettore vuoto)
    s  = [];
    % azzeramento conteggio delle iterazioni del ciclo while
    it = 0;
    while n > 1
        % aggiornamento del numero di iterazioni
        it = it + 1;
        if mod (n, 2) == 0 % controlla se n e' pari
            n=n/2;
        else
            n = 3 * n + 1;
        end
        s = [s n]; % accoda il nuovo n alla successione
    end
    iterazioni = [iterazioni it]; % accoda il nuovo numero di iterazioni
    % stampo il numero di iterazioni del ciclo while
    it
    % stampo tutti gli elementi della successione
    s    
end

%% sottosezione 2

% Grafico n_0 vs. iterazioni
plot(n0, iterazioni);