clc
clear

x=3; y=-2;
f=atan(y/x)-sin(x*sqrt(abs(y)))^2
