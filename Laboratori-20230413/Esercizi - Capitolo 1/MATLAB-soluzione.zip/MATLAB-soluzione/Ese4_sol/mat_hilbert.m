clc;
clear all;
close all;

% definisco la dimensione voluta
n = 5;

% dichiaro la matrice con dimensione n
A = zeros (n, n);

% ciclo per attribuire i valori alla matrice
for i = 1:n
    for j = 1:n
        A (i, j) = 1 / (i + j - 1);
    end
end

% stampo la matrice risultato
A

% stampo la matrice di Hilbert usando il comando di Matlab
hilb_5 = hilb(5)

% calcolo e stampo la differenza tra A e la matrice che devo ottenere
difference = A - hilb_5
