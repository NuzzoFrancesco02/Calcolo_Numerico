clc
clear

k = 0; % per esempio
x=0:1:1000;

r=mod(x,k+2);

S = 0;
for ii = 1:length(x)
    if r(ii) ~= 0
        S = S + (x(ii));
    end
end
S
