clc
clear

kappa = 1;
geometrica([1:(10+kappa)])
