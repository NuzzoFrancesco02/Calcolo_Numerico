clc
clear

kappa = 1;
armonica([1:(10+kappa)])