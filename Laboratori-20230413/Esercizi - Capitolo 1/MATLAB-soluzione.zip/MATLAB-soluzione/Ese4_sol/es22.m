function [] = es22(a,b,c)
lati=sort([a b c]);
ip=max(lati);
cat1=lati(1); cat2=lati(2);
if cat1^2 + cat2^2 == ip^2
    disp('E'' un triangolo rettangolo');
else
    disp('Non e'' un triangolo rettangolo');
end
end
