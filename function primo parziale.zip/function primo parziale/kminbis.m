function k=kminbis(a,b,tol)
k=ceil(log2((b-a)/tol-1));
end