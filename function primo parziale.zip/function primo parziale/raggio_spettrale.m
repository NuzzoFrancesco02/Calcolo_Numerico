function[r]=raggio_spettrale(A)
     r=max(abs(eig(A)));
end

