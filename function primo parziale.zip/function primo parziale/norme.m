function x=norme(v,A)
x=sqrt(v'*A*v);
end