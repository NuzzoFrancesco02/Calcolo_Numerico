clc
close all
clear all

% Es 1
f = @( x ) exp( - x.^2 ) .* sin( 2 * x + 1 );
df = @( x ) 2 * ( cos( 2 * x + 1 ) - x .* sin( 2 * x + 1 ) ) .* exp( - x.^2 );

xb = 0;
dfxb = df( xb );
h_v = 0.4 * 2.^( - [ 0 : 5 ] );
dfa_v = [];
dfi_v = [];
dfc_v = [];
for h = h_v
    dfa_v = [ dfa_v, ( f( xb + h ) - f( xb ) ) / h ];
    dfi_v = [ dfi_v, ( f( xb ) - f( xb - h ) ) / h ];
    dfc_v = [ dfc_v, ( f( xb + h ) - f( xb - h ) ) / ( 2 * h ) ];
end
Err_dfa_v = abs( dfa_v - dfxb );
Err_dfi_v = abs( dfi_v - dfxb );
Err_dfc_v = abs( dfc_v - dfxb );

figure( 1 )
loglog( h_v, Err_dfa_v, '-ob', ...
    h_v, Err_dfi_v, '-xr', ...
    h_v, Err_dfc_v, '-sg', ...
    h_v, h_v, '--k', h_v, h_v.^2, '-.k', ...
    'LineWidth', 2, 'MarkerSize', 10 );
xlabel( 'h [log]' ); ylabel( 'Err [log]' )
legend( 'DF avanti', 'DF indietro', 'DF centrate', 'h', 'h^2', 'Location', 'Best' );
grid on
% settings_4_plot_no_LaTeX

% Es 2
d2f = @( x ) - 2 * ( 3 * sin( 2 * x + 1 ) + 4 * x .* cos( 2 * x + 1 ) ...
    - 2 * x.^2 .* sin( 2 * x + 1 ) ) .* exp( - x.^2 );
d2fxb = d2f( xb );

d2fc_v = [];
for h = h_v
    d2fc_v = [ d2fc_v, ( f( xb + h ) - 2 * f( xb ) + f( xb - h ) ) / ( h^2 ) ];
end
Err_d2fc_v = abs( d2fc_v - d2fxb );

figure( 2 )
loglog( h_v, Err_d2fc_v, '-sb', ...
    h_v, h_v, '--k', h_v, h_v.^2, '-.k', ...
    'LineWidth', 2, 'MarkerSize', 10 );
xlabel( 'h [log]' ); ylabel( 'Err [log]' )
legend( 'DF centrate', 'h', 'h^2', 'Location', 'Best' );
grid on
settings_4_plot_no_LaTeX