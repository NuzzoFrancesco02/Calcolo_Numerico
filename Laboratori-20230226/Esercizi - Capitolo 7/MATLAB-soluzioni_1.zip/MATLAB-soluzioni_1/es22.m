%% Lab 15 es 3
%
% soluzione esatta: b exp(lambda*t), con c=lambda*b
clc
clear
close all

% valori iniziali dei dati
y0 = 2;

tmax = 10;

t_plot=0:0.01:tmax;

y=@(t) exp( - t / 2 ) .* ( 2 + sin( pi * t ) ); 

plot(t_plot,y(t_plot));

title('Soluzione analitica','FontSize',20)

%% punto 2: risolvo con eulero in avanti

% t_h e' l'insieme dei nodi in cui e' calcolata la soluzione, u_h e' la soluzione discreta
% questo e' il termine di destra della EDO
f= @(t,y) pi * y .* cos( pi * t) ./ ( sin( pi * t ) + 2 ) - y / 2;
h = 0.05;
[EA_t_h,EA_u_h]=eulero_avanti(f,tmax,y0,h);


% confronto il risultato con la soluzione esatta
figure;
plot(t_plot,y(t_plot),'k','LineWidth',2);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

hold on;

plot(EA_t_h,EA_u_h,'o','MarkerSize',4);

leg=legend('soluzione analitica','soluzione calcolata con EA, h=0.05');

set(leg,'FontSize',16)

% confronto con un passo piu' fine
h=0.01;
[EA_t_h_fine,EA_u_h_fine]=eulero_avanti(f,tmax,y0,h);

figure;
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on
plot(EA_t_h,EA_u_h,'o','MarkerSize',4);
plot(EA_t_h_fine,EA_u_h_fine,'or','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','EA con h=0.05','EA con h=0.01');

set(leg,'FontSize',16)


%% punto 4: risolvo con eulero indietro
% la sintassi della chiamata e' la stessa di prima
h=0.05;
[EI_t_h,EI_u_h,iter_pf]=eulero_indietro(f,tmax,y0,h);

% confronto il risultato con la soluzione esatta
figure;
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h,EI_u_h,'o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI, h=0.05');

set(leg,'FontSize',16)

% confronto con un passo piu' fine
h=0.01;
[EI_t_h_fine,EI_u_h_fine]=eulero_indietro(f,tmax,y0,h);

figure;
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on

plot(EI_t_h,EI_u_h,'o','MarkerSize',4);

plot(EI_t_h_fine,EI_u_h_fine,'or','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','EI con h=0.05','EI con h=0.01');

set(leg,'FontSize',16)

%% punto 5: iterazioni di punto fisso
% visualizzo le sottoiterazioni di punto fisso ad ogni iterazione 
figure;

plot(EI_t_h,iter_pf,'o:','MarkerSize',4)

xlabel('istante','FontSize',16);
ylabel('iterazioni di punto fisso','FontSize',16);



%% punto 6: grafici errore
N=5;
dimezz=2.^(1:N);
passi=0.08./dimezz;

for it=1:N
      [EA_t_h,EA_u_h]=eulero_avanti( f, tmax, y0, passi(it) );
      [EI_t_h,EI_u_h]=eulero_indietro( f, tmax, y0, passi(it) );
      y_h=y( 0 : passi(it) : tmax  );
      errore_EA(it)=max( abs (y_h-EA_u_h) );
      errore_EI(it)=max( abs (y_h-EI_u_h) );
end

figure;

loglog(passi,errore_EA,'-ob','LineWidth',2);
hold on
loglog(passi,errore_EI,'-or','LineWidth',2);

plot(passi,100*passi,'k')
plot(passi,(10*passi).^2,'k:')

xlabel('h','FontSize',16);
lab=ylabel('err(h)','FontSize',16,'Rotation',0);
set(lab,'Position',[0.0007 0.2])

leg=legend('errore EA','errore EI','ordine 1','ordine 2');

set(leg,'FontSize',16)