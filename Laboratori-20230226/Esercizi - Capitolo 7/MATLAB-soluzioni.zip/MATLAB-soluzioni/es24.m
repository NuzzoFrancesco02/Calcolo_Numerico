%% esercizio 2
 
clear
close all
clc

%% punto 1
y0=2;
lambda=-42;

tmax=1;

t_plot=0:0.01:tmax;

y=@(x) y0*exp(lambda*x);


%% risolvo con Crank Nicolson

% questo e' il termine di destra della EDO

f= @(t,y) lambda*y;

% la sintassi della chiamata e' la stessa di prima

h=0.02;

[CN_t_h,CN_u_h,iter_pf]=Crank_Nicolson(f,tmax,y0,h);

figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(CN_t_h,CN_u_h,'or','MarkerSize',4);

%title('soluzione approssimata con Crank-Nicolson','FontSize',20)

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con CN, h=0.02');

set(leg,'FontSize',16)

%title('sottoiterazioni di punto fisso','FontSize',16)

figure

plot(iter_pf,'o:','MarkerSize',4)

xlabel('istante','FontSize',16);
ylabel('iterazioni di punto fisso','FontSize',16);


%title('sottoiterazioni di punto fisso','FontSize',16)

h=0.02;

[H_t_h,H_u_h]=Heun(f,tmax,y0,h);


% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(H_t_h,H_u_h,'or','MarkerSize',4);

%title('soluzione approssimata con Heun','FontSize',20)

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con H, h=0.02');

set(leg,'FontSize',16)



%% grafici errore

%passi=0.05:-0.01:0.01;
N=5;
dimezz=2.^(1:N);
passi=0.04./dimezz;


for it=1:N
      [EI_t_h, EI_u_h] = eulero_indietro_pto_fisso( f, tmax, y0, passi(it) );
      [CN_t_h, CN_u_h] = Crank_Nicolson( f, tmax, y0, passi(it) );
      [H_t_h, H_u_h] = Heun( f, tmax, y0, passi(it) );
      [RK_t_h, RK_u_h] = Runge_Kutta_4(f, tmax, y0, passi(it));
      y_h=y( 0 : passi(it) : tmax  );
      errore_EI(it) = max( abs (y_h-EI_u_h) );
      errore_CN(it) = max( abs (y_h-CN_u_h) );
      errore_H(it) = max( abs (y_h-H_u_h) );
      errore_RK(it) = max( abs (y_h-RK_u_h) );
end

figure;

loglog(passi,errore_CN,'-o','LineWidth',2);
hold on
loglog(passi,errore_H,'-o','LineWidth',2);
loglog(passi,errore_EI,'-o','LineWidth',2);
loglog(passi,errore_RK,'-o','LineWidth',2);
plot(passi,passi,'k')
plot(passi,(passi).^2,'k--')
plot(passi,(passi).^4,'k-.')
grid on

xlabel('h','FontSize',16);
lab=ylabel('err(h)','FontSize',16,'Rotation',0);
set(lab,'Position',[0.0007 0.2])

leg=legend('errore CN','errore H', 'errore EI','errore RK','ordine 1','ordine 2','ordine 4');

set(leg,'FontSize',16)