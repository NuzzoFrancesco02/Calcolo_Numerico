%%% esercizio 3
clc
close all
clear all

t0 = 0;
tf = 300;  
N = 1e7;
E0 = 100;
I0 = 30;
S0 = N - E0 - I0;
y0 = [ S0 E0 I0 ]';
h = 0.25;
Nh = round( ( tf - t0 ) / h );

[ tEA, uEA ] = eulero_avanti_sistemi( @seir, [ t0 tf ], y0, Nh );
REA = N - uEA( 1, : ) - uEA( 2, : ) - uEA( 3, : );

figure( 1 )
plot( tEA, uEA( 1, : ), '-b', tEA, uEA( 2, : ), '-r', ...
      tEA, uEA( 3, : ), '-m', tEA, REA, '-k', 'LineWidth', 2 );
xlabel( 't [giorni]' );
ylabel( '# per compartimento');
legend( 'S', 'E', 'I', 'R', 'Location', 'Best' );
grid on
%settings_4_plot_no_LaTeX

% 
beta = 0.7586;
alpha = 1 / 5.2;
gamma = 1 / 2.9;

Lambda = @( it, uEA) [ - beta / N * uEA( 3, it ), 0, - beta / N * uEA( 1, it );
                         beta / N * uEA( 3, it ), - alpha,  beta / N * uEA( 1, it );
                         0, alpha, - gamma ];
for it = 1 : length( tEA )
    lambda_h_EA( :, it ) = h * eig( Lambda( it, uEA ) );
end

figure( 2 )
th = linspace( 0, 2 * pi, 301 ); 
 
plot( real( lambda_h_EA ), imag( lambda_h_EA ), 'x', cos( th ) - 1, sin( th ), '-k',...
      'LineWidth', 2, 'MarkerSize', 6 ); 
xlabel( 'Re( lambda h)' );
ylabel( 'Im( lambda h)' );
grid on
axis( [ -2.5 0.5 -1.5 1.5 ] )
axis equal
title( 'Ass. stab. EA' );
%settings_4_plot_no_LaTeX


figure( 3 )
subplot( 2, 1, 1 )
plot(tEA, real(lambda_h_EA(1, :))/h, ...
     tEA, real(lambda_h_EA(2, :))/h, ...
     tEA, real(lambda_h_EA(3, :))/h, 'LineWidth', 2);
grid on
xlabel( 't [giorni]' );
ylabel( 'Re( lambda )');
legend( 'Re( lambda_1 )', 'Re( lambda_2 )', 'Re( lambda_3 )' );
%settings_4_plot_no_LaTeX
subplot( 2, 1, 2 )
plot(tEA, imag(lambda_h_EA(1, :))/h, ...
     tEA, imag(lambda_h_EA(2, :))/h, ...
     tEA, imag(lambda_h_EA(3, :))/h, 'LineWidth', 2);
grid on
xlabel( 't [giorni]' );
ylabel( 'Im( lambda )');
legend( 'Im( lambda_1 )', 'Im( lambda_2 )', 'Im( lambda_3 )' );
%settings_4_plot_no_LaTeX

% trovo la posizione dei lambda(t)*h che possono appartenere alla regione
% di assoluta stabilita'
lambda_h_EA_region = max( sqrt( ( real( lambda_h_EA ) + 1 ).^2 + ( imag( lambda_h_EA ) ).^2 ), [], 1 );
ilambda_h = find( lambda_h_EA_region < 1, 1 );
t_bar = tEA( ilambda_h )

figure( 4 )
th = linspace( 0, 2 * pi, 301 ); 
 plot( real( lambda_h_EA( :, ilambda_h + 1 : end ) ), imag( lambda_h_EA( :, ilambda_h + 1 : end ) ), 'x', cos( th ) - 1, sin( th ), '-k',...
      'LineWidth', 2, 'MarkerSize', 6 ); 
xlabel( 'Re( lambda h)' );
ylabel( 'Im( lambda h)' );
grid on
axis( [ -2.5 0.5 -1.5 1.5 ] )
axis equal
title( strcat( 'Ass. stab. EA per t >', num2str( round( t_bar ) ), ' ', ' giorni' ) );
% settings_4_plot_no_LaTeX
