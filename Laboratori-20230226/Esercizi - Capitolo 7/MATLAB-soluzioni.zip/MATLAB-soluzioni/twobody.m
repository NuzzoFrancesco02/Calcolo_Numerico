function f = twobody( t, y )
%
% TWO BODY Function - Sun (assumed fixed in space) - Earth
% y( 1 ) = x_e Earth
% y( 2 ) = dx_e/dt Earth
% y( 3 ) = y_e Earth
% y( 4 ) = dy_e/dt Earth
%
% Dimensionless eqs. UA units
%

[ n, m ] = size( y ); 
f = zeros( n, m ); 

Den = ( y( 1 )^2 + y( 3 )^2 )^( 3 / 2 );

f( 1 ) = y( 2 ); 
f( 2 ) = 4 * pi^2 * ( - y( 1 ) / Den ); 
f( 3 ) = y( 4 ); 
f( 4 ) = 4 * pi^2 * ( - y( 3 ) / Den ); 

return