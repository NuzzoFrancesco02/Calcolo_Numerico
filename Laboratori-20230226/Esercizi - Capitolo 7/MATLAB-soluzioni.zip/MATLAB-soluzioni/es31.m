%% Esercizio 1
clc, close all, clear all
[t,u] = ode45('mms',[0 100],[2 0]);
[tf,uf] = ode45('mms_forz',[0 100],[2 0]);
plot(t,u(:,1),'b',tf,uf(:,1),'r')
legend('Oscillazione smorzata','Con forzante esterna')

