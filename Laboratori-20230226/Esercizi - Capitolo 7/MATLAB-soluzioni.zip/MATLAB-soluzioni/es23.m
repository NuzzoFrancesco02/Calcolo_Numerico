%% esercizio 1

clear
clc
close all

%% punto 1
lambda = -42;
y0=2;
t_max=1;

t_plot=0:0.001:t_max;

y=@(t) y0*exp(lambda*t);

f=@(t,y) lambda * y;
df_dy = @(t, y) lambda;

figure

plot(t_plot,y(t_plot),'k','LineWidth',2);
leg=legend('y0 e^{\lambda t}');

set(leg,'FontSize',16);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

%%  punto 2
h=0.05;

%%%%% EULERO IN AVANTI %%%%%%
[t_h,u_h]=eulero_avanti(f,t_max,y0,h);


% confronto il risultato con la soluzione esatta
figure
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

%questa e' la sol. calcolata
plot(t_h,u_h,'-o','MarkerSize',4);

leg=legend('soluzione analitica','soluzione calcolata con EA, h = 0.05');

set(leg,'FontSize',16);

%%%%% EULERO ALL'INDIETRO %%%%%%
% rifaccio tutto con Eulero Implicito

[EI_t_h,EI_u_h]=eulero_indietro_newton(f,df_dy,t_max,y0,h);


figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h,EI_u_h,'-o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI-newton, h = 0.05');

set(leg,'FontSize',16);

%% punto 3
%%%%% EULERO IN AVANTI %%%%%%
% risolvo nuovamente con EA, stavolta prendo h in modo tale da garantire 
% la convergenza del metodo. Non convergera' invece EI

h2=0.01;

[t_h2,u_h2]=eulero_avanti(f,t_max,y0,h2);


% confronto il risultato con la soluzione esatta
figure ();
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

%questa e' la sol. calcolata con h2

plot(t_h2,u_h2,'-o','MarkerSize',4);

leg=legend('soluzione analitica','soluzione di EA, h = 0.01');

set(leg,'FontSize',16);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);


%%%%% EULERO ALL'INDIETRO %%%%%%

[EI_t_h2,EI_u_h2]=eulero_indietro_newton(f,df_dy,t_max,y0,h2);

figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h2,EI_u_h2,'-o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI-newton, h = 0.01');

set(leg,'FontSize',16);


%%  punto 4a
h=0.05;


%%%%% EULERO IN AVANTI %%%%%%
[t_h,u_h]=eulero_avanti(f,t_max,y0,h);


% confronto il risultato con la soluzione esatta
figure
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

%questa e' la sol. calcolata
plot(t_h,u_h,'-o','MarkerSize',4);

leg=legend('soluzione analitica','soluzione calcolata con EA, h = 0.05');

set(leg,'FontSize',16);

%%%%% EULERO ALL'INDIETRO %%%%%%
% rifaccio tutto con Eulero Implicito, che in teoria non ha problemi. 
% In realta' la nostra implementazione introduce un vincolo
% per hlambda, a causa della implementazione come punto fisso.  


% risolvo con passo h, che non garantisce la convergenza di EA
[EI_t_h,EI_u_h,vett_it_pf]=eulero_indietro_pto_fisso(f,t_max,y0,h);


figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h,EI_u_h,'-o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI-pto fisso, h = 0.05');

set(leg,'FontSize',16);

% se il punto fisso non converge raggiungo ad ogni passo temporale il
% massimo numero di iterazioni possibili:

figure

plot(vett_it_pf,'-o','MarkerSize',4)

legend ('Numero di iterazioni di punto fisso')


%% punto 4b
%%%%% EULERO IN AVANTI %%%%%%
% risolvo nuovamente con EA, stavolta prendo h in modo tale da garantire 
% la convergenza del metodo. Non convergera' invece EI

h2=0.03;

[t_h2,u_h2]=eulero_avanti(f,t_max,y0,h2);


% confronto il risultato con la soluzione esatta
figure 
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

%questa e' la sol. calcolata con h2

plot(t_h2,u_h2,'-o','MarkerSize',4);

leg=legend('soluzione analitica','soluzione di EA, h = 0.03');

set(leg,'FontSize',16);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);


%%%%% EULERO ALL'INDIETRO %%%%%%
% se infatti risolvo con EI con passo h2, che garantisce la convergenza di 
% EA ma e' ancora esterno alla zona di convergenza del punto
% fisso, EI non funziona

[EI_t_h2,EI_u_h2]=eulero_indietro_pto_fisso(f,t_max,y0,h2);

figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h2,EI_u_h2,'-o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI-pto fisso, h = 0.03');

set(leg,'FontSize',16);


%% punto 4c
% infine utilizzo un passo h3  

%%%%% EULERO IN AVANTI %%%%%%
h3=0.01;

[t_h3,u_h3]=eulero_avanti(f,t_max,y0,h3);


% confronto il risultato con la soluzione esatta
figure ()
plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;


% questa e' la sol. calcolata con h3

plot(t_h3,u_h3,'-o','MarkerSize',4);


leg=legend('soluzione analitica','soluzione di EA, h = 0.01');

set(leg,'FontSize',16);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);
%set(lab,'Position',[0.0007 0.2])


%%%%% EULERO ALL'INDIETRO %%%%%%
% infine risolvo con passo h3, che garantisce la convergenza di EI
[EI_t_h3,EI_u_h3]=eulero_indietro_pto_fisso(f,t_max,y0,h3);


figure
% confronto il risultato con la soluzione esatta

plot(t_plot,y(t_plot),'k','LineWidth',2);

hold on;

plot(EI_t_h3,EI_u_h3,'-o','MarkerSize',4);

xlabel('t','FontSize',16);
ylabel('y(t)','FontSize',16,'Rotation',0);

leg=legend('soluzione analitica','soluzione calcolata con EI-pto fisso, h = 0.01');

set(leg,'FontSize',16);