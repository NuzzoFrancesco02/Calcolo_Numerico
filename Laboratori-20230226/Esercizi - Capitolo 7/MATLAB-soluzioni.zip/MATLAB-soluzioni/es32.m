clc
close all
clear all

% Esercizio 2
t0 = 0;
tf = 5;
y0 = [ 1 0 0 -5.1 ]';

% ODE45
options = odeset('reltol' ,1e-6);
[ tv, uv ] = ode45( 'twobody', [ t0 tf ], y0, options );
uv = uv';

figure( 1 )
plot( tv, uv( 1, : ), '--k', tv, uv( 3, : ), '--m', 'LineWidth', 2 );
grid on
axis( [ t0 tf -2 2 ] ); axis tight
xlabel('t'); ylabel('x, y');
% settings_4_plot_no_LaTeX

figure( 2 )
plot( 0, 0, 'xk', uv( 1, 1 ), uv( 3, 1 ), 'sb', ...
      uv( 1, : ), uv( 3, : ), '-b', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel('x'); ylabel('y');
axis equal
axis( [ -2 2 -2 2 ] ); 
grid on
% settings_4_plot_no_LaTeX

% figure( 23 )
% plot( tv(1:end-1), tv(2:end)-tv(1:end-1), 'LineWidth', 2); 
% xlabel( 't'); ylabel('h'); 
% settings_4_plot_no_LaTeX
% grid on

% Eulero in avanti
h = 1e-3;
Nh = round( ( tf - t0 ) / h );

[ tEA, uEA ] = eulero_avanti_sistemi( @twobody, [ t0 tf ], y0, Nh );

figure( 3 )
plot( tEA, uEA( 1, : ), '--k', tEA, uEA( 3, : ), '--m', 'LineWidth', 2 );
grid on
axis( [ t0 tf -2 2 ] ); axis tight
xlabel('t'); ylabel('x, y');
% settings_4_plot_no_LaTeX

figure( 4 )
plot( 0, 0, 'xk', uEA( 1, 1 ), uEA( 3, 1 ), 'sb', ...
      uEA( 1, : ), uEA( 3, : ), '-b', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel('x'); ylabel('y');
axis equal
axis( [ -2 2 -2 2 ] ); 
grid on
% settings_4_plot_no_LaTeX
