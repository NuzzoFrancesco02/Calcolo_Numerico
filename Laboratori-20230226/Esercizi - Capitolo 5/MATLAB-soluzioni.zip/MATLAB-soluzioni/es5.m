clear
clc
close all
%%
fun = @(x) exp(-x.^2).*sin(x);
a = -2;
b = 3;
x_dis = linspace(a,b,1000);
f_dis = fun(x_dis);

figure(1)
plot(x_dis,f_dis,'k', 'linewidth', 2)

n=3;
h=(b-a)/n;
x_nod = a:h:b;
f_nod = fun(x_nod);
P_dis = interp1(x_nod,f_nod,x_dis);
hold on;
plot(x_nod,f_nod,'bo', 'linewidth', 2)
plot(x_dis,P_dis,'b', 'linewidth', 2)
legend('f(x)','nodi','interpolante composito lineare')

%%
err = max(abs(f_dis-P_dis))
%%
H = [];
err_max=[];
for n = 2.^(2:7)
    h = (b - a)/n;
    H = [H h];
    x_nod = a:h:b;
    f_nod = fun(x_nod);
    P_dis = interp1(x_nod,f_nod,x_dis);
    err_max = [err_max;max(abs(P_dis-f_dis))];
end
%%
figure(2)
loglog(H,err_max,'ro-',H,H,'k--',H,H.^2,'k', 'linewidth', 2)
legend('errore','H','H^2')