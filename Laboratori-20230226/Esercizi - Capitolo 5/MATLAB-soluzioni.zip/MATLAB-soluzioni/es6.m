clc
close all
clear all

% esercizio 6

% 3.1
T = 1;
ts = linspace( 0, T, 11 );
ys = [ 10.0 9.89 9.75 9.66 9.10 8.95 8.10 7.49 6.80 6.13 5.05 ];

y0 = 10.0;
g = 9.81;
y = @(t) y0 - 1 / 2 * g * t.^2;

tv = linspace( 0, T, 1001 );
yv = y( tv );

figure( 1 );
plot( ts, ys, 'om', tv, yv, '-b', 'MarkerSize', 13, 'LineWidth', 2 );
grid on
xlabel( 't [s]' ); ylabel( 'y [m]' );
legend( '(ts,ys)', 'y(t)', 'Location', 'Best' );
% settings_4_plot_no_LaTeX

% 3.2
n = length( ys ) - 1;
Pi_n_v = polyval( polyfit( ts, ys, n ), tv );  % interpolante polinomiale

PiH_1_v = interp1( ts, ys, tv ); % interpolante lineare a tratti

Pmq_2_v = polyval( polyfit( ts, ys, 2 ), tv );  % approssimante minimi quadrati

figure( 2 );
plot( ts, ys, 'om', tv, yv, '-b', ...
      tv, Pi_n_v, '-k', ...
      tv, PiH_1_v, '-g', ...
      tv, Pmq_2_v, '-r', ...
      'MarkerSize', 13, 'LineWidth', 2 );
grid on
xlabel( 't [s]' ); ylabel( 'y [m]' );
legend( '(ts,ys)', 'y(t)', 'Pi_n(t)', 'PiH_1(t)', 'Pmq_2(t)', 'Location', 'Best' );
% settings_4_plot_no_LaTeX

E_Pi_n_v = abs( Pi_n_v - yv );      % errori
E_PiH_1_v = abs( PiH_1_v - yv );
E_Pmq_2_v = abs( Pmq_2_v - yv );

figure( 3 );
plot( tv, E_Pi_n_v, '-k', ...
      tv, E_PiH_1_v, '-g', ...
      tv, E_Pmq_2_v, '-r', ...
      'MarkerSize', 13, 'LineWidth', 2 );
grid on
xlabel( 't [s]' ); ylabel( 'errori [m]' );
legend( 'Pi_n(t)', 'PiH_1(t)', 'Pmq_2(t)', 'Location', 'Best' );
%settings_4_plot_no_LaTeX

[ e_Pi_n, i_Pi_n ] = max( E_Pi_n_v );
e_Pi_n, tmax_e_Pi_n = tv( i_Pi_n )
[ e_PiH_1, i_PiH_1 ] = max( E_PiH_1_v );
e_PiH_1, tmax_PiH_1 = tv( i_PiH_1 )
[ e_Pmq_2, i_Pmq_2 ] = max( E_Pmq_2_v );
e_Pmq_2, tmax_Pmq_2 = tv( i_Pmq_2 )

% 3.3
Tf = 1.05;
tv = linspace( 0, Tf, 1001 );
Pi_n_v = polyval( polyfit( ts, ys, n ), tv );  % interpolante polinomiale
Pmq_2_v = polyval( polyfit( ts, ys, 2 ), tv );  % approssimante minimi quadrati

figure( 4 );
plot( ts, ys, 'om', tv, yv, '-b', ...
      tv, Pi_n_v, '-k', ...
      tv, Pmq_2_v, '-r', ...
      'MarkerSize', 13, 'LineWidth', 2 );
grid on
xlabel( 't [s]' ); ylabel( 'y [m]' );
legend( '(ts,ys)', 'y(t)', 'Pi_n(t)', 'Pmq_2(t)', 'Location', 'Best' );


yTf = y( Tf )
yTf_Pi_n_v = Pi_n_v( end )
yTf_Pmq_2_v = Pmq_2_v( end )
