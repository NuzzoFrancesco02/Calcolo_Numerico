clc
close all
clear all

a = 0;
b = 1;
alpha = 0;
beta = 0;
mu = 1;
% f = @( x ) - sin( pi / 2 * x );
f = @( x ) - ( 2 * x - 1 ) .* ( x >= 1/2 )

h = 0.05;
N = round( ( b - a ) / h ) - 1;
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N, N ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
A = mu / h^2 * A;

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
bv( end ) = bv( end ) + beta * mu / h^2;

uh = A \ bv;

uh = [ alpha; uh; beta ];

sigmah = [ ( uh( 2 ) - uh( 1 ) ) / h; 
           ( uh( 3 : end ) - uh( 1 : end - 2 ) ) / 2 / h;
           ( uh( end ) - uh( end - 1 ) ) / h ];  
       
qa = - sigmah( 1 )
qb = sigmah( end )

xplot = linspace( a, b, 1001 );

figure( 1 );
subplot( 3, 1, 1 );
plot( xplot, f( xplot), '-b', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'f(x) ')
%settings_4_plot_no_LaTeX

subplot( 3, 1, 2 );
plot( xnodes, uh, 'xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uh ')
%settings_4_plot_no_LaTeX

subplot( 3, 1, 3 );
plot( xnodes, sigmah, 'sk', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'sigmah ')
%settings_4_plot_no_LaTeX