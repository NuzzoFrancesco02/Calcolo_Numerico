clear all
close all
clc

a = 0;
b = 1;
delta = 1;
beta = exp( 2 ) - 1;
mu = 0.5;
eta = 2;
sigma = @( x ) x;
f = @( x ) 2 * exp( 2 * x ) + x .* ( exp( 2 * x ) - 1 );
uex = @( x ) exp( 2 * x ) - 1;

% 3
N = 100 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 2 : N + 1, 2 : N + 1, 2, N + 1, N + 1 ) ...
    + sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) + sparse( 2 : N, 3 : N + 1, -1, N + 1, N + 1 ); 
A = mu / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) ...
                            + sparse( 2 : N, 3 : N + 1, 1, N + 1, N + 1 ) );
A = A + sparse( 2 : N + 1, 2 : N + 1, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

A( 1, 1 : 2 ) = mu / h * [ -1 1 ];

bv = ( f( xnodes( 1 : end - 1 ) ) )';
bv( 1 ) = delta;
bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

uh = A \ bv;

uh = [ uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 1 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate & in avanti', 'location', 'Best' );
settings_4_plot_no_LaTeX

% 4
Nv = [ 50 100 200 400 800 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 2 : N + 1, 2 : N + 1, 2, N + 1, N + 1 ) ...
        + sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) + sparse( 2 : N, 3 : N + 1, -1, N + 1, N + 1 ); 
    A = mu / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) ...
                            + sparse( 2 : N, 3 : N + 1, 1, N + 1, N + 1 ) );
    A = A + sparse( 2 : N + 1, 2 : N + 1, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

    A( 1, 1 : 2 ) = mu / h * [ -1 1 ];

    bv = ( f( xnodes( 1 : end - 1 ) ) )';
    bv( 1 ) = delta;
    bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

    uh = A \ bv;

    uh = [ uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 2 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
settings_4_plot_no_LaTeX

% 5
N = 100 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 2 : N + 1, 2 : N + 1, 2, N + 1, N + 1 ) ...
    + sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) + sparse( 2 : N, 3 : N + 1, -1, N + 1, N + 1 ); 
A = mu / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) ...
                            + sparse( 2 : N, 3 : N + 1, 1, N + 1, N + 1 ) );
A = A + sparse( 2 : N + 1, 2 : N + 1, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

A( 1, 1 : 3 ) = mu / ( 2 * h ) * [ -3 4 -1 ];

bv = ( f( xnodes( 1 : end - 1 ) ) )';
bv( 1 ) = delta;
bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

uh = A \ bv;

uh = [ uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 3 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate & ord.2', 'location', 'Best' );
settings_4_plot_no_LaTeX

% 6
Nv = [ 50 100 200 400 800 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
    
    A = sparse( 2 : N + 1, 2 : N + 1, 2, N + 1, N + 1 ) ...
        + sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) + sparse( 2 : N, 3 : N + 1, -1, N + 1, N + 1 ); 
    A = mu / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N + 1, 1 : N, -1, N + 1, N + 1 ) ...
                            + sparse( 2 : N, 3 : N + 1, 1, N + 1, N + 1 ) );
    A = A + sparse( 2 : N + 1, 2 : N + 1, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

    A( 1, 1 : 3 ) = mu / ( 2 * h ) * [ -3 4 -1 ];

    bv = ( f( xnodes( 1 : end - 1 ) ) )';
    bv( 1 ) = delta;
    bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

    uh = A \ bv;

    uh = [ uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 4 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
settings_4_plot_no_LaTeX


