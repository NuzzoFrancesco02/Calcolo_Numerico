FontSize = 20;
set( gca, 'FontSize', FontSize, 'FontName', 'TimesNewRoman' )
xlhand = get( gca, 'xlabel' );
set( xlhand, 'FontSize', FontSize, 'FontName', 'TimesNewRoman' )
ylhand = get( gca, 'ylabel' );
set( ylhand, 'FontSize', FontSize, 'FontName', 'TimesNewRoman' )
tlhand = get( gca, 'title' );
set( tlhand, 'FontSize', FontSize, 'FontName', 'TimesNewRoman' )


% LateX fonts
%set( xlhand, 'interpreter', 'latex')
%set( ylhand, 'interpreter', 'latex')
%set( tlhand, 'interpreter', 'latex')
%llhand = legend;
%set( llhand, 'interpreter', 'latex')
