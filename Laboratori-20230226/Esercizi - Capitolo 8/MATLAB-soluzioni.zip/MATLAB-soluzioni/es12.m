clear all
close all
clc

a = 0;
b = 1;
alpha = 1;
beta = exp( 3 );
mu = 1;
sigma = @( x ) 1 + sin( 2 * pi * x );
f = @( x ) exp( 3 * x ) .* ( sin( 2 * pi * x ) - 8 );
uex = @( x ) exp( 3 * x );

% 3

N = 20 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N, N ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
A = mu / h^2 * A;
A = A + sparse( diag( sigma( xnodes( 2 : end - 1 ) ) ) );

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
bv( end ) = bv( end ) + beta * mu / h^2;

uh = A \ bv;

uh = [ alpha; uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 1 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, 'xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate', 'location', 'Best' );
% settings_4_plot_no_LaTeX


% 4
hv = [ 0.04 0.02 0.01 0.005 0.0025 ];
Nv = round( ( b - a ) ./ hv ) - 1;
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N, N ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
    A = mu / h^2 * A;
    A = A + sparse( diag( sigma( xnodes( 2 : end - 1 ) ) ) );
    
    bv = ( f( xnodes( 2 : end - 1 ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
    bv( end ) = bv( end ) + beta * mu / h^2;

    uh = A \ bv;

    uh = [ alpha; uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 2 )
loglog( hv, errv, '-x', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h^2)', 'Location', 'Best' );
grid on
% settings_4_plot_no_LaTeX

