clear;
clc;

%% Punto 1: EqCalore_DiffFin_Theta.m

%% Punto 2.

% Estremi dell'intervallo.
a = 0;
b = 1;

% Tempo finale.
T = 1;

% Dati funzionali.
mu = 1;
f = @(x,t) (-sin(t) + 0.25 * cos(t)) * sin(0.5*x); % Termine forzante.
u_ex = @(x,t) sin(0.5*x) * cos(t); % Soluzione esatta.
u_s = @(t) 0 * cos(t); % Dato di Dirichlet in x = a.
u_d = @(t) sin(0.5) * cos(t); % Dato di Dirichlet in x = b.
g_0 = @(x) sin(0.5*x); % Dato iniziale.

theta = 1; % Parametro del theta-metodo.
h = 0.01; % Passo di discretizzazione in spazio.
delta_t = 0.1; % Passo di discretizzazione in tempo.

% Risolvo il problema con la funzione EqCalore_DiffFin_Theta
[u, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, theta);

% Plot della soluzione esatta e di quella numerica all'istante finale.
figure;
plot(x, u(:,end), '-', x, u_ex(x,T), '--', 'LineWidth', 2);
legend('Soluzione numerica', 'Soluzione esatta', 'Location', 'SouthEast');
xlabel('x');
ylabel('u_h');
title(['Eulero implicito, h = ' num2str(h) ', \Deltat = ' num2str(delta_t)]);

figure
for k = 1 : length( t )
    plot( x, u( :, k ), '-k' );
    xlabel('x');    ylabel('u_h');
    grid on
    title(['Eulero implicito, t = ' num2str( t(k) ) ] );
    axis([ 0 1 0 0.5 ] );
    pause( 0.1 );
end       

%% Punto 3.

% (a)
theta = 0;
h = 0.01;
delta_t = 0.1;
[u, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, theta);

% Plot della soluzione esatta e di quella numerica all'istante finale.
figure;
plot(x, u(:,end), '-', x, u_ex(x,T), '--', 'LineWidth', 2);
legend('Soluzione numerica', 'Soluzione esatta', 'Location', 'SouthEast');
xlabel('x');
ylabel('u_h');
title(['Eulero esplicito, h = ' num2str(h) ', \Deltat = ' num2str(delta_t)]);

% (b)
theta = 0;
h = 0.1;
delta_t = 0.001;
[u, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, theta);

% Plot della soluzione esatta e di quella numerica all'istante finale.
figure;
plot(x, u(:,end), '-', x, u_ex(x,T), '--', 'LineWidth', 2);
legend('Soluzione numerica', 'Soluzione esatta', 'Location', 'SouthEast');
xlabel('x');
ylabel('u_h');
title(['Eulero esplicito, h = ' num2str(h) ', \Deltat = ' num2str(delta_t)]);

%% Punto  4.

% Eulero implicito, Crank-Nicolson.
err_ei = [];
err_cn = [];
err_cn_h0005 = [];

h = 0.1; % Passo di discretizzazione in spazio.

% Vettore dei passi di discretizzazione in tempo.
delta_t_vec = [0.1, 0.05, 0.025, 0.0125, 0.00625, 0.003125];

for delta_t = delta_t_vec
    [u_ei, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, 1);
    err_ei(end+1) = max(abs(u_ei(:,end) - u_ex(x', T)));
    
    [u_cn, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, 0.5);
    err_cn(end+1) = max(abs(u_cn(:,end) - u_ex(x', T)));
    
    [u_cn, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, 0.005, delta_t, 0.5);
    err_cn_h0005(end+1) = max(abs(u_cn(:,end) - u_ex(x', T)));
end

% Plot logaritmico di errore vs. delta_t
figure;
loglog(delta_t_vec, err_ei, 'o-', delta_t_vec, err_cn, 'o-', ...
       delta_t_vec, err_cn_h0005, 'o-', ...
       delta_t_vec, delta_t_vec, '--', delta_t_vec, delta_t_vec.^2, '--');
legend('Eulero implicito, h = 0.1', 'Crank-Nicolson, h = 0.1', ...
    'Crank-Nicolson, h = 0.005', '\Deltat', '\Deltat^2', ...
    'Location', 'SouthEast');
title('Errore vs. \Deltat, Eulero implicito e Crank-Nicolson');
grid on
xlabel('\Delta t [log]')
ylabel('e_T [log]')

% Eulero esplicito.
delta_t_vec = [0.001, 0.0005, 0.00025, 0.000125, 0.0000625, 0.00003125];
err_ea = [];

for delta_t = delta_t_vec
    [u_ea, x, t] = EqCalore_DiffFin_Theta(mu, f, a, b, u_s, u_d, g_0, T, h, delta_t, 0);
    err_ea(end+1) = max(abs(u_ea(:,end) - u_ex(x', T)));
end

% Plot logaritmico di errore vs. delta_t
figure;
loglog(delta_t_vec, err_ea, 'o-', delta_t_vec, delta_t_vec, '--');
legend('Eulero esplicito, h = 0.1', '\Deltat', ...
    'Location', 'SouthEast');
title('Errore vs. \Deltat, Eulero esplicito');
grid on
xlabel('\Delta t [log]')
ylabel('e_T [log]')