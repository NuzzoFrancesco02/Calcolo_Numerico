clear all
close all
clc

a = 0;
b = 1;
alpha = 1;
gamma = - exp( 3 );
mu = 1;
eta = 0;
sigma = @( x ) 0 * x;
f = @( x ) exp( 3 * x ) .* ( - 4 + 3 * x + 9 * x.^2 );
uex = @( x ) exp( 3 * x ) .* ( x - x.^2 ) + 1;

% 3
N = 100 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N + 1, N + 1 ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) + sparse( 1 : N, 2 : N + 1, -1, N + 1, N + 1 ); 
A = mu / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) ...
                            + sparse( 1 : N, 2 : N + 1, 1, N + 1, N + 1 ) );
A = A + sparse( 1 : N, 1 : N, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

A( end, N : N + 1 ) = mu / h * [ -1 1 ];

bv = ( f( xnodes( 2 : end ) ) )';
bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
bv( end ) = gamma;

uh = A \ bv;

uh = [ alpha; uh ];

xplot = linspace( a, b, 1001 );
figure( 1 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate & indietro', 'location', 'Best' );
settings_4_plot_no_LaTeX

% 4
Nv = [ 50 100 200 400 800 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N + 1, N + 1 ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) + sparse( 1 : N, 2 : N + 1, -1, N + 1, N + 1 ); 
    A = mu / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) ...
                            + sparse( 1 : N, 2 : N + 1, 1, N + 1, N + 1 ) );
    A = A + sparse( 1 : N, 1 : N, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

    A( end, N : N + 1 ) = mu / h * [ -1 1 ];

    bv = ( f( xnodes( 2 : end ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
    bv( end ) = gamma;

    uh = A \ bv;

    uh = [ alpha; uh ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 2 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
settings_4_plot_no_LaTeX

% 5
N = 100 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N + 1, N + 1 ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) + sparse( 1 : N, 2 : N + 1, -1, N + 1, N + 1 ); 
A = mu / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) ...
                            + sparse( 1 : N, 2 : N + 1, 1, N + 1, N + 1 ) );
A = A + sparse( 1 : N, 1 : N, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

A( end, N - 1 : N + 1 ) = mu / ( 2 * h ) * [ 1 -4 3 ];

bv = ( f( xnodes( 2 : end ) ) )';
bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
bv( end ) = gamma;

uh = A \ bv;

uh = [ alpha; uh ];

xplot = linspace( a, b, 1001 );
figure( 3 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate & ord.2', 'location', 'Best' );
settings_4_plot_no_LaTeX

% 4
Nv = [ 50 100 200 400 800 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N + 1, N + 1 ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) + sparse( 1 : N, 2 : N + 1, -1, N + 1, N + 1 ); 
    A = mu / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N + 1, N + 1 ) ...
                            + sparse( 1 : N, 2 : N + 1, 1, N + 1, N + 1 ) );
    A = A + sparse( 1 : N, 1 : N, sigma( xnodes( 2 : end - 1 ) ), N + 1, N + 1 );         

    A( end, N - 1 : N + 1 ) = mu / ( 2 * h ) * [ 1 -4 3 ];

    bv = ( f( xnodes( 2 : end ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
    bv( end ) = gamma;

    uh = A \ bv;

    uh = [ alpha; uh ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 4 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
settings_4_plot_no_LaTeX


