clear 
close all
clc

%% Punto 2)
a = 0; 
b = 1; 
c = 0; 
d = 1; 

uex= @(x, y) sin(pi*x).*sin(2*pi*y); 
h = 1e-1; 
xvect = a:h:b; 
yvect = c:h:d; 
[Xplot, Yplot] = meshgrid(xvect, yvect); 
surf(Xplot, Yplot, uex(Xplot, Yplot), 'Lines','no')
xlabel('x')
ylabel('y')
zlabel('u_{ex}(x, y)')

%% Punto 3) 
mu = 1; 
f = @(x, y) 5*pi^2*sin(pi*x).*sin(2*pi*y); 
g = @(x, y) 0; 
Omega = [a b c d]; 
hx = 1e-1; 
hy = 1e-1; 

[ X, Y, U ] = Poisson_Dirichlet_diff_finite_5punti( mu, f, g, Omega, hx, hy ); 
figure
surf(X, Y, U)
xlabel('x')
ylabel('y')
zlabel('u_{h}')

%% Punto 4)
hvect = 0.1*2.^[0:-1:-4];
errvect = zeros(size(hvect));

for i = 1:length(hvect)
    h = hvect(i); 
    [ X, Y, U ] = Poisson_Dirichlet_diff_finite_5punti( mu, f, g, Omega, h, h ); 
    errvect(i) = max(max((abs(U - uex(X, Y) )))); 
end
figure
loglog(hvect, errvect, 'o-', 'LineWidth', 2, 'MarkerSize', 10)
hold on
loglog(hvect, hvect, 'k--', 'LineWidth', 2, 'MarkerSize', 10)
loglog(hvect, hvect.^2, 'k-.', 'LineWidth', 2, 'MarkerSize', 10)
legend('errore', 'lineare', 'quadratico', 'location', 'best')
grid on
xlabel( ' h [log]' );
ylabel( 'err [log]')
