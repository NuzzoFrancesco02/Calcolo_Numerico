clear all
close all
clc

a = 0;
b = 1;
alpha = 1;
beta = -2;
mu = 1;
f = @( x ) exp( 3 * x ) .* ( - 4 + 3 * x + 9 * x.^2 );
uex = @( x ) exp( 3 * x ) .* ( x - x.^2 ) + 1 - 3 * x;

% 3

N = 20 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N, N ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
A = mu / h^2 * A;

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
bv( end ) = bv( end ) + beta * mu / h^2;

uh = A \ bv;

uh = [ alpha; uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 1 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, 'xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate', 'location', 'Best' );
% settings_4_plot_no_LaTeX


% 4
Nv = [ 10 20 40 80 160 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N, N ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
    A = mu / h^2 * A;

    bv = ( f( xnodes( 2 : end - 1 ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
    bv( end ) = bv( end ) + beta * mu / h^2;

    uh = A \ bv;

    uh = [ alpha; uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 2 )
loglog( hv, errv, '-x', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h^2)', 'Location', 'Best' );
grid on
% settings_4_plot_no_LaTeX

% 5
K2v = [];
for N = Nv
    
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N, N ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
    A = mu / h^2 * A;
    K2v = [ K2v, condest( A ) ];
end
figure( 3 )
loglog( hv, K2v, '-x', hv, hv.^(-2), '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'K2(A) [log]')
legend( 'K2(A)', '(h,1/h^2)', 'Location', 'Best' );
grid on
% settings_4_plot_no_LaTeX

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * mu / h^2;
bv( end ) = bv( end ) + beta * mu / h^2;

uh = A \ bv;

eh = max( abs( uh - uex( xnodes( 2 : end - 1 )' ) ) )

err_sist_lin_stimato = condest( A ) * norm( bv - A * uh ) / norm( bv ) * norm( uh )

