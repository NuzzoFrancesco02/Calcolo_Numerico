clear all
close all
clc

a = 0;
b = 1;
alpha = 0;
beta = 1;
mu = 1e-2;
eta = 1;
f = @( x ) 0 * x;
uex = @( x ) ( exp( eta / mu * x ) - 1 ) / ( exp( eta / mu ) - 1 ); 

% 3, 4
N = 20 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
A = sparse( 1 : N, 1 : N, 2, N, N ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
A = mu / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N, N ) ...
                            + sparse( 1 : N - 1, 2 : N, 1, N, N ) );

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

uh = A \ bv;

uh = [ alpha; uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 1 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh DF centrate', 'location', 'Best' );
%settings_4_plot_no_LaTeX

h_max = 2 * mu / abs( eta )

% 5
Nv = [ 30 60 120 240 480 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    A = sparse( 1 : N, 1 : N, 2, N, N ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
    A = mu / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, - 1, N, N ) ...
                                + sparse( 1 : N - 1, 2 : N, 1, N, N ) );


    bv = ( f( xnodes( 2 : end - 1 ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * ( mu / h^2 + eta / ( 2 * h ) );
    bv( end ) = bv( end ) + beta * ( mu / h^2 - eta / ( 2 * h ) );

    uh = A \ bv;

    uh = [ alpha; uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 2 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
%settings_4_plot_no_LaTeX

% 7
N = 20 - 1;
h = ( b - a ) / ( N + 1 );
xnodes = linspace( a, b, N + 2 );
  
Peh = abs( eta ) * h / ( 2 * mu );
muh = mu * ( 1 + Peh );

A = sparse( 1 : N, 1 : N, 2, N, N ) ...
    + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
A = muh / h^2 * A;
A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, -1, N, N ) ...
                            + sparse( 1 : N - 1, 2 : N, 1, N, N ) );

bv = ( f( xnodes( 2 : end - 1 ) ) )';
bv( 1 ) = bv( 1 ) + alpha * ( muh / h^2 + eta / ( 2 * h ) );
bv( end ) = bv( end ) + beta * ( muh / h^2 - eta / ( 2 * h ) );

uh = A \ bv;

uh = [ alpha; uh; beta ];

xplot = linspace( a, b, 1001 );
figure( 3 );
plot( xplot, uex( xplot ), '-b', xnodes, uh, ':xr', 'LineWidth', 2, 'MarkerSize', 10 );
grid on
xlabel( 'x' );
ylabel( 'uex, uh ')
legend( 'u_{ex}', 'uh upwind', 'location', 'Best' );
%settings_4_plot_no_LaTeX

Pe_star = eta * h / ( 2 * muh );

% 5
Nv = [ 30 60 120 240 480 ] - 1;
hv = ( b - a ) ./ ( Nv + 1 );
errv = [];
for N = Nv
    
    xnodes = linspace( a, b, N + 2 );
    h = ( b - a ) / ( N + 1 );
  
    Peh = abs( eta ) * h / ( 2 * mu );
    muh = mu * ( 1 + Peh );

    A = sparse( 1 : N, 1 : N, 2, N, N ) ...
        + sparse( 2 : N, 1 : N - 1, -1, N, N ) + sparse( 1 : N - 1, 2 : N, -1, N, N ); 
    A = muh / h^2 * A;
    A = A + eta / ( 2 * h ) * ( sparse( 2 : N, 1 : N - 1, - 1, N, N ) ...
                                + sparse( 1 : N - 1, 2 : N, 1, N, N ) );


    bv = ( f( xnodes( 2 : end - 1 ) ) )';
    bv( 1 ) = bv( 1 ) + alpha * ( muh / h^2 + eta / ( 2 * h ) );
    bv( end ) = bv( end ) + beta * ( muh / h^2 - eta / ( 2 * h ) );

    uh = A \ bv;

    uh = [ alpha; uh; beta ];
    
    errv = [ errv, max( abs( uh - uex( xnodes' ) ) ) ];
end

figure( 4 )
loglog( hv, errv, '-x', hv, hv, '-.k', hv, hv.^2, '--k', 'LineWidth', 2, 'MarkerSize', 10 );
xlabel( ' h [log]' );
ylabel( 'err [log]')
legend( 'eh', '(h,h)', '(h,h^2)', 'Location', 'Best' );
grid on
%settings_4_plot_no_LaTeX
