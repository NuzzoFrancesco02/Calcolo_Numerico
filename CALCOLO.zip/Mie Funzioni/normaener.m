function nor = normaener(v,A)

% Restituisce la "norma energia" di x in relazione alla matrice A

nor = sqrt(v'*A*v);
end