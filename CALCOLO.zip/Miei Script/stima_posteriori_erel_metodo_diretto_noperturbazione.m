clear
clc

K2 = ;	%K2
r = ;	%norma2
b = ;	%norma2
e_rel = K2 * r /b